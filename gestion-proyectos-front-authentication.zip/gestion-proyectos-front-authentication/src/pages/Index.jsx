import React from 'react';

const Index = () => {
  return (
    <div>
      <div className='bg-green-300 h-96'>Index page</div>
      <div className='bg-green-300 h-96'>Index page</div>
      <div className='bg-green-300 h-96'>Index page</div>
      <div className='bg-green-300 h-96'>Index page</div>
    </div>
  );
};

export default Index;
