import React from 'react';

const Category1 = () => {
  return <div>pagina /category/page1</div>;
};

export default Category1;
