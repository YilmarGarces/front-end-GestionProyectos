import React from 'react';

const IndexCategory1 = () => {
  return <div>Index Category1</div>;
};

export default IndexCategory1;
