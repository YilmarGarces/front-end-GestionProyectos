# Boilerplate para el proyecto de Misión TIC - Ciclo 4 UdeA 2021

### ¿Cómo usar este proyecto?

Paso 1: clonar el proyecto

`git clone `

Paso 2: navegar hacia la carpeta e instalar dependencias

`yarn install`

Paso 3: ejecutar el proyecto

`yarn start`
